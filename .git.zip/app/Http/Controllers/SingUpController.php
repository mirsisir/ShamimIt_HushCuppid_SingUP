<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SingUpController extends Controller
{
    public function sing_up(Request $request){


    }
}
