<?php return array (
  'singup-component' => 'App\\Http\\Livewire\\SingupComponent',
);